
Commit
=========================================
.. automodule:: Commit
    :show-inheritance:
    :members:
    :undoc-members:
