
ecgroup
=========================================
.. automodule:: ecgroup
    :show-inheritance:
    :members:
    :undoc-members:
